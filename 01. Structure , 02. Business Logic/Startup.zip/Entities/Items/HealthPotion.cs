﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WarCroft.Entities.Items
{
    public class HealthPotion : Item
    {
        public HealthPotion()
            : base(5)
        {

        }
    }
}
